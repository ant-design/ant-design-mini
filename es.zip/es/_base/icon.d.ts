
export declare type IconType = string;
