export interface IBaseProps {
    /**
     * @description 类名
     */
    className?: string;
}
