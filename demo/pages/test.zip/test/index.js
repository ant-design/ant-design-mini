import regionData from './city'
Page({
  data: {
    cityList: [ regionData.province, regionData.city['11']]
  },

  handlePickerChange(value, wholeValue ) {
    console.log('change', value, wholeValue )
    this.setData({
      cityList: [regionData.province, regionData.city[value[0]]],
    });
  },

  handleOnOk(value, column) {
    console.log('value', value, 'column', column)
  }
})